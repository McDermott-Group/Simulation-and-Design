:mod:`gdsii` --- GDSII manipulation library
===========================================

.. toctree::
   :maxdepth: 2

   library
   structure
   elements
   tags
   types
   record
   exceptions
